import React from 'react';


export default class CurrentWorkout {



	// display first workout
	// display for 10 seconds
	// switch to next work out
	// continue until all workouts have been gone through
	// display finished!

	render() {
		return(
			<div>{props.workoutList}</div>
		)
	}

}
